# Reel Shelf

Android app for your anime, movie and series watchlist. Share any Instagram reel to it and it saves the title with poster, details and where to watch.

## Get the APK
Every push to this repo builds the app automatically. Open the **Releases** section on the repo page and download `ReelShelf.apk` from the newest build. Install it (allow "Install unknown apps" for your browser or file manager when Android asks).

## First run
1. Open Settings (gear icon) and paste a free TMDB API key (themoviedb.org, Settings, API) so movies and series get posters and where-to-watch info.
2. In Instagram, tap Share on a reel, then More, then Reel Shelf.

## Build on a PC instead
Open this folder in Android Studio and run Build, Build APK.
