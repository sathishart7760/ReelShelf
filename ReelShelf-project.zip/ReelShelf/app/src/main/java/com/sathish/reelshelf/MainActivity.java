package com.sathish.reelshelf;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {

    private static final String HOME = "https://appassets.androidplatform.net/assets/index.html";
    private static final int PICK_FILE = 41;

    private WebView web;
    private volatile boolean pageReady = false;
    private String pendingShare = null;
    private ValueCallback<Uri[]> fileCallback;
    private boolean loginOpened = false;
    static final String IG_UA = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36";
    static final String DESKTOP_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36";

    static boolean igLoggedIn() {
        String c = CookieManager.getInstance().getCookie("https://www.instagram.com");
        return c != null && c.contains("sessionid=");
    }

    static String cookieValue(String all, String name) {
        if (all == null) return "";
        for (String part : all.split(";")) {
            String t = part.trim();
            if (t.startsWith(name + "=")) return t.substring(name.length() + 1);
        }
        return "";
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (loginOpened && pageReady) {
            loginOpened = false;
            web.evaluateJavascript("window.onIgLogin && window.onIgLogin(" + igLoggedIn() + ")", null);
        } else if (pageReady) {
            web.evaluateJavascript("window.onAppResume && window.onAppResume()", null);
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        web = new WebView(this);
        web.setBackgroundColor(0xFF241C3A);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(true);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("appassets.androidplatform.net".equals(u.getHost())) return false;
                openExternal(u.toString());
                return true;
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                String[] types = params.getAcceptTypes();
                i.setType(types != null && types.length > 0 && types[0] != null && types[0].startsWith("image") ? "image/*" : "*/*");
                try {
                    startActivityForResult(Intent.createChooser(i, "Choose backup file"), PICK_FILE);
                } catch (Exception e) {
                    fileCallback = null;
                    return false;
                }
                return true;
            }
        });

        CookieManager.getInstance().setAcceptCookie(true);
        web.addJavascriptInterface(new Bridge(), "Android");
        handleIntent(getIntent());
        web.loadUrl(HOME);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIntent(intent);
    }

    private void handleIntent(Intent intent) {
        if (intent == null || !Intent.ACTION_SEND.equals(intent.getAction())) return;
        String text = intent.getStringExtra(Intent.EXTRA_TEXT);
        if (text == null || text.trim().isEmpty()) return;
        if (pageReady) {
            web.evaluateJavascript("window.onShared && window.onShared(" + JSONObject.quote(text) + ")", null);
        } else {
            pendingShare = text;
        }
    }

    private void openExternal(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception ignored) { }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == PICK_FILE && fileCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        web.evaluateJavascript("(window.onBack && window.onBack()) ? 'yes' : 'no'", value -> {
            if (value == null || !value.contains("yes")) {
                if (web.canGoBack()) web.goBack(); else finish();
            }
        });
    }

    /** Called from the web page as window.Android.* */
    private class Bridge {

        @JavascriptInterface
        public String ready() {
            pageReady = true;
            String p = pendingShare;
            pendingShare = null;
            return p;
        }

        @JavascriptInterface
        public void openUrl(String url) {
            runOnUiThread(() -> openExternal(url));
        }

        /** Fetches a page natively (no browser CORS limits) and returns {status, body} to window.__native(id, json). */
        @JavascriptInterface
        public boolean igLoggedIn() {
            return MainActivity.igLoggedIn();
        }

        @JavascriptInterface
        public void igLogin() {
            runOnUiThread(() -> {
                loginOpened = true;
                startActivity(new Intent(MainActivity.this, LoginActivity.class));
            });
        }

        @JavascriptInterface
        public void igLogout() {
            CookieManager.getInstance().removeAllCookies(null);
            CookieManager.getInstance().flush();
        }

        /** Instagram web API call using the cookies from the in-app Instagram login. */
        @JavascriptInterface
        public void fetchIg(final String url, final String id) {
            fetch(url, IG_UA, id, true);
        }

        @JavascriptInterface
        public void fetchText(final String url, final String userAgent, final String id) {
            fetch(url, userAgent, id, false);
        }

        private void fetch(final String url, final String userAgent, final String id, final boolean ig) {
            new Thread(() -> {
                JSONObject out = new JSONObject();
                HttpURLConnection c = null;
                try {
                    c = (HttpURLConnection) new URL(url).openConnection();
                    c.setInstanceFollowRedirects(true);
                    c.setConnectTimeout(15000);
                    c.setReadTimeout(15000);
                    if (userAgent != null && !userAgent.isEmpty()) c.setRequestProperty("User-Agent", userAgent);
                    c.setRequestProperty("Accept", "text/html,application/xhtml+xml");
                    c.setRequestProperty("Accept-Language", "en-US,en;q=0.9");
                    if (ig) {
                        String cookies = CookieManager.getInstance().getCookie("https://www.instagram.com");
                        if (cookies != null) c.setRequestProperty("Cookie", cookies);
                        c.setRequestProperty("X-CSRFToken", cookieValue(cookies, "csrftoken"));
                        c.setRequestProperty("X-IG-App-ID", "1217981644879628");
                        c.setRequestProperty("X-ASBD-ID", "129477");
                        c.setRequestProperty("X-IG-WWW-Claim", "0");
                        c.setRequestProperty("Origin", "https://www.instagram.com");
                        c.setRequestProperty("X-Requested-With", "XMLHttpRequest");
                        c.setRequestProperty("Referer", "https://www.instagram.com/");
                        c.setRequestProperty("Accept", "application/json");
                    }
                    int code = c.getResponseCode();
                    out.put("status", code);
                    InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                    if (in != null) {
                        ByteArrayOutputStream buf = new ByteArrayOutputStream();
                        byte[] b = new byte[8192];
                        int n, total = 0;
                        while ((n = in.read(b)) != -1 && total < 3_000_000) {
                            buf.write(b, 0, n);
                            total += n;
                        }
                        in.close();
                        out.put("body", buf.toString("UTF-8"));
                    }
                } catch (Exception e) {
                    try { out.put("status", 0); out.put("error", String.valueOf(e.getMessage())); } catch (Exception ignored) { }
                } finally {
                    if (c != null) c.disconnect();
                }
                final String js = "window.__native(" + JSONObject.quote(id) + "," + JSONObject.quote(out.toString()) + ")";
                runOnUiThread(() -> web.evaluateJavascript(js, null));
            }).start();
        }

        /** Downloads a picture and asks trace.moe which anime it is from. */
        @JavascriptInterface
        public void traceImage(final String imageUrl, final String id) {
            new Thread(() -> {
                JSONObject out = new JSONObject();
                try {
                    HttpURLConnection d = (HttpURLConnection) new URL(imageUrl).openConnection();
                    d.setConnectTimeout(15000);
                    d.setReadTimeout(20000);
                    d.setRequestProperty("User-Agent", IG_UA);
                    InputStream din = d.getInputStream();
                    ByteArrayOutputStream img = new ByteArrayOutputStream();
                    byte[] b = new byte[8192];
                    int n;
                    while ((n = din.read(b)) != -1) img.write(b, 0, n);
                    din.close();
                    d.disconnect();

                    HttpURLConnection c = (HttpURLConnection) new URL("https://api.trace.moe/search?anilistInfo&cutBorders").openConnection();
                    c.setRequestMethod("POST");
                    c.setDoOutput(true);
                    c.setConnectTimeout(20000);
                    c.setReadTimeout(40000);
                    c.setRequestProperty("Content-Type", "image/jpeg");
                    try (OutputStream os = c.getOutputStream()) { os.write(img.toByteArray()); }
                    int code = c.getResponseCode();
                    out.put("status", code);
                    InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                    if (in != null) {
                        ByteArrayOutputStream buf = new ByteArrayOutputStream();
                        while ((n = in.read(b)) != -1) buf.write(b, 0, n);
                        in.close();
                        out.put("body", buf.toString("UTF-8"));
                    }
                    c.disconnect();
                } catch (Exception e) {
                    try { out.put("status", 0); out.put("error", String.valueOf(e.getMessage())); } catch (Exception ignored) { }
                }
                final String js = "window.__native(" + JSONObject.quote(id) + "," + JSONObject.quote(out.toString()) + ")";
                runOnUiThread(() -> web.evaluateJavascript(js, null));
            }).start();
        }

        /** Saves a text file into the phone's Downloads folder. */
        @JavascriptInterface
        public String saveFile(String name, String content) {
            try {
                ContentValues v = new ContentValues();
                v.put(MediaStore.Downloads.DISPLAY_NAME, name);
                v.put(MediaStore.Downloads.MIME_TYPE, name.endsWith(".xml") ? "application/xml" : "application/json");
                v.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri uri = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v);
                if (uri == null) return "Could not save the file";
                try (OutputStream os = getContentResolver().openOutputStream(uri)) {
                    os.write(content.getBytes(StandardCharsets.UTF_8));
                }
                return "Saved to Downloads: " + name;
            } catch (Exception e) {
                return "Could not save: " + e.getMessage();
            }
        }
    }
}
