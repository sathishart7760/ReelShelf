plugins {
    id("com.android.application")
}

android {
    namespace = "com.sathish.reelshelf"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.sathish.reelshelf"
        minSdk = 29
        targetSdk = 34
        versionCode = 7
        versionName = "1.6"
    }

    signingConfigs {
        create("release") {
            // Fixed key so every new build installs over the old one and keeps your data
            storeFile = file("reelshelf.jks")
            storePassword = "reelshelf123"
            keyAlias = "reelshelf"
            keyPassword = "reelshelf123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("release")
        }
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
}
